import logging
import os
import datetime
import time
from datetime import datetime
from functools import lru_cache

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class MemoryEngine:
    DECAY_FACTOR = 0.1
    CACHE_SIZE = 128

    def __init__(self, db):
        self.db = db
        self.memory_cache = {}
        self._setup_index()

    def _setup_index(self):
        """Ensure the full-text index exists in Neo4j."""
        try:
            self.db.run_query(
                "CREATE FULLTEXT INDEX memoryIndex FOR (n:Memory) ON EACH [n.text]"
            )
            logger.info("Full-text index 'memoryIndex' created or already exists.")
        except Exception as e:
            logger.error(f"Failed to create or check index 'memoryIndex': {e}")
    
    @lru_cache(maxsize=CACHE_SIZE)
    def search_memory(self, text):
        if text in self.memory_cache:
            logger.debug(f"[CACHE HIT] Found in memory cache: {text}")
            return self.memory_cache[text]

        query = """
            CALL db.index.fulltext.queryNodes('memoryIndex', $text)
            YIELD node, score
            WHERE score > 0.7
            MATCH (node)-[:SHARES_EMOTION]-(connected)
            RETURN node.text AS text, COALESCE(node.emotion, 'neutral') AS emotion, 
                node.weight AS weight, node.last_updated AS last_updated, 
                COLLECT(connected.text) AS related_memories
            ORDER BY score DESC LIMIT 1
            """
        try:
            result = self.db.run_query(query, {"text": text.lower()})
            if result:
                self.memory_cache[text] = result[0]
                logger.info(f"[CACHE STORE] Stored in cache: {text}")
                return result[0]
        except Exception as e:
            logger.error(f"Query failed: {e}")
            return None

        logger.warning(f"[SEARCH MISS] No memory found for: {text}")
        return None

    def store_memory(self, text, emotion='neutral', additional_data=None):
        timestamp = datetime.now().isoformat()
    try:
        query = """
            MERGE (m:Memory {text: $text})
            ON CREATE SET m.created_at = $timestamp, m.weight = 1, m.emotion = $emotion
            ON MATCH SET m.last_updated = $timestamp, m.emotion = $emotion

            // Connect this node to all other nodes with the same emotion
            WITH m
            MATCH (other:Memory)
            WHERE other.emotion = m.emotion AND id(other) <> id(m)
            MERGE (m)-[:SHARES_EMOTION]->(other)
            """
        self.db.run_query(query, {
            "text": text.lower(),
            "emotion": emotion.lower(),
            "timestamp": timestamp
        })
        logger.info(f"[MEMORY STORED] '{text}' | Emotion: '{emotion}'")
    except Exception as e:
        logger.error(f"[STORE FAILED] Memory storage failed: {e}", exc_info=True)
    
    def analyze_cycles(self):
        query = """
            MATCH path = (m:Memory)-[:SHARES_EMOTION*]->(m)
            WHERE length(path) > 0
            RETURN nodes(path) AS cycle, length(path) AS length, 
                collect(m.emotion) AS emotions
            """
        results = self.db.run_query(query)
        for result in results:
            cycle_data = {
                'nodes': [node['text'] for node in result['cycle']],
                'length': result['length'],
                'emotions': result['emotions']
            }
            # Here you would log or store this data for further analysis
            logger.info(f"Cycle detected: {cycle_data}")